"""
Airflow Connection 등록 스크립트
=================================
실행 방법:
  docker exec mds_airflow_web python /opt/airflow/scripts/setup_connections.py

등록되는 커넥션:
  - postgres_mds : mds_postgres (airflow DB)
"""

from airflow.models import Connection
from airflow import settings
from sqlalchemy.exc import IntegrityError

CONNECTIONS = [
    {
        "conn_id"   : "postgres_mds",
        "conn_type" : "postgres",
        "host"      : "mds_postgres",   # Docker 컨테이너명
        "schema"    : "airflow",
        "login"     : "airflow",
        "password"  : "airflow",
        "port"      : 5432,
        "description": "MDS PostgreSQL - raw/staging/marts 스키마",
    },
]

session = settings.Session()

for c in CONNECTIONS:
    existing = session.query(Connection).filter_by(conn_id=c["conn_id"]).first()
    if existing:
        print(f"[SKIP] 이미 존재: {c['conn_id']}")
        continue

    conn = Connection(
        conn_id     = c["conn_id"],
        conn_type   = c["conn_type"],
        host        = c["host"],
        schema      = c["schema"],
        login       = c["login"],
        password    = c["password"],
        port        = c["port"],
        description = c.get("description", ""),
    )
    try:
        session.add(conn)
        session.commit()
        print(f"[OK] 등록 완료: {c['conn_id']} → {c['host']}:{c['port']}/{c['schema']}")
    except IntegrityError:
        session.rollback()
        print(f"[FAIL] 등록 실패: {c['conn_id']}")

session.close()
