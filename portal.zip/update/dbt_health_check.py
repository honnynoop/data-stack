#!/usr/bin/env python3
"""
dbt 환경 헬스체크 스크립트
============================
실행 방법:
  docker exec mds_airflow_web python /opt/airflow/scripts/dbt_health_check.py

확인 항목:
  1. dbt 설치 버전
  2. /opt/dbt 폴더 존재 여부
  3. profiles.yml host 설정
  4. PostgreSQL 직접 연결 테스트
"""

import subprocess
import os
import sys

DBT_DIR = "/opt/dbt"
CHECKS  = []

def ok(msg):  CHECKS.append(("✅", msg))
def fail(msg): CHECKS.append(("❌", msg))
def warn(msg): CHECKS.append(("⚠️ ", msg))

# ── 1. dbt 설치 확인 ─────────────────────────────────────
result = subprocess.run(["dbt", "--version"], capture_output=True, text=True)
if result.returncode == 0:
    version = result.stdout.strip().split("\n")[0]
    ok(f"dbt 설치 확인: {version}")
else:
    fail("dbt가 설치되지 않았습니다")

# ── 2. /opt/dbt 폴더 확인 ────────────────────────────────
if os.path.isdir(DBT_DIR):
    ok(f"dbt 프로젝트 폴더 존재: {DBT_DIR}")
else:
    fail(f"폴더 없음: {DBT_DIR}  →  zip 파일을 컨테이너에 복사 후 압축 해제 필요")

# ── 3. dbt_project.yml 확인 ──────────────────────────────
yml = os.path.join(DBT_DIR, "dbt_project.yml")
if os.path.isfile(yml):
    ok(f"dbt_project.yml 존재")
else:
    fail("dbt_project.yml 없음")

# ── 4. profiles.yml host 확인 ────────────────────────────
prof = os.path.join(DBT_DIR, "profiles.yml")
if os.path.isfile(prof):
    content = open(prof).read()
    if "mds_postgres" in content:
        ok("profiles.yml host = mds_postgres (정상)")
    elif "postgres" in content:
        warn("profiles.yml host = 'postgres' → 'mds_postgres' 로 수정 권장")
    else:
        fail("profiles.yml host 설정 확인 필요")
else:
    fail("profiles.yml 없음")

# ── 5. PostgreSQL 연결 테스트 ─────────────────────────────
try:
    import psycopg2
    conn = psycopg2.connect(
        host="mds_postgres", port=5432,
        dbname="airflow", user="airflow", password="airflow",
        connect_timeout=5,
    )
    conn.close()
    ok("PostgreSQL 연결 성공: mds_postgres:5432/airflow")
except Exception as e:
    fail(f"PostgreSQL 연결 실패: {e}")

# ── 결과 출력 ────────────────────────────────────────────
print("\n" + "="*50)
print("  dbt 환경 헬스체크 결과")
print("="*50)
for icon, msg in CHECKS:
    print(f"  {icon}  {msg}")
print("="*50)

failed = sum(1 for icon, _ in CHECKS if icon == "❌")
if failed:
    print(f"\n  ❌ {failed}개 항목 실패 — 위 항목을 확인하세요")
    sys.exit(1)
else:
    print("\n  모든 체크 통과 — dbt run 준비 완료!")
