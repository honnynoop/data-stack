"""
DAG: dbt data_stack 전체 실행 파이프라인
=========================================
실행 순서 : dbt debug → staging run → marts run → dbt test → 완료 알림
스케줄    : 매일 새벽 02:00
dbt 경로  : /opt/dbt  (컨테이너 mds_airflow_web 내부)
작성일    : 2026-05-08
"""

from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.bash import BashOperator

# ── 경로 상수 ────────────────────────────────────────────
DBT_DIR = "/opt/dbt"          # 실제 확인된 경로

# ── 기본 인자 ─────────────────────────────────────────────
default_args = {
    "owner"           : "data_team",
    "depends_on_past" : False,
    "retries"         : 1,
    "retry_delay"     : timedelta(minutes=5),
    "email_on_failure": False,
}

# ── DAG 정의 ──────────────────────────────────────────────
with DAG(
    dag_id           = "dbt_data_stack_daily",
    default_args     = default_args,
    description      = "dbt data_stack: raw → staging(VIEW) → marts(TABLE) 매일 갱신",
    schedule_interval= "0 2 * * *",        # 매일 02:00
    start_date       = datetime(2024, 1, 1),
    catchup          = False,
    tags             = ["dbt", "data_stack", "ecommerce"],
) as dag:

    # ── Task 1 : 연결 사전 확인 ───────────────────────────
    t_debug = BashOperator(
        task_id      = "dbt_debug",
        bash_command = f"cd {DBT_DIR} && dbt debug",
    )

    # ── Task 2 : staging 모델 (VIEW 4개) ─────────────────
    t_staging = BashOperator(
        task_id      = "dbt_run_staging",
        bash_command = f"cd {DBT_DIR} && dbt run --select staging",
    )

    # ── Task 3 : marts 모델 (TABLE 4개) ──────────────────
    t_marts = BashOperator(
        task_id      = "dbt_run_marts",
        bash_command = f"cd {DBT_DIR} && dbt run --select marts",
    )

    # ── Task 4 : 데이터 품질 테스트 (31개) ───────────────
    t_test = BashOperator(
        task_id      = "dbt_test",
        bash_command = f"cd {DBT_DIR} && dbt test",
    )

    # ── Task 5 : 완료 로그 ───────────────────────────────
    t_done = BashOperator(
        task_id      = "pipeline_done",
        bash_command = """
            echo "================================================"
            echo " dbt data_stack 파이프라인 완료: $(date '+%Y-%m-%d %H:%M:%S')"
            echo " staging VIEW 4개 + marts TABLE 4개 갱신 완료"
            echo "================================================"
        """,
    )

    # ── 의존성 (순차 실행) ────────────────────────────────
    t_debug >> t_staging >> t_marts >> t_test >> t_done
